import json
from telegram import Bot
import asyncio
from datetime import datetime
import jdatetime
import os
import pytz
import time
import traceback

last_report = None

# خواندن تنظیمات
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "master_config.json")
with open(CONFIG_PATH) as f:
    config = json.load(f)

API_TOKEN = config['telegram']['API_TOKEN']
CHANNEL_ID = config['telegram']['CHANNEL_ID']


# تبدیل تاریخ میلادی به شمسی
import jdatetime
import pytz
from datetime import datetime

def get_shamsi_time(last_update):
    # منطقه زمانی تهران
    tehran_tz = pytz.timezone('Asia/Tehran')

    # تبدیل تایم‌استمپ به زمان محلی تهران
    last_update_time = datetime.fromtimestamp(last_update, tz=pytz.utc).astimezone(tehran_tz)

    # تبدیل به تاریخ شمسی
    jdate = jdatetime.datetime.fromgregorian(datetime=last_update_time)

    # معادل فارسی روزهای هفته
    weekdays_fa = ['دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه', 'یک‌شنبه']
    
    # معادل فارسی ماه‌ها
    months_fa = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
                 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند']

    # گرفتن روز هفته و ماه به فارسی
    weekday_fa = weekdays_fa[jdate.weekday()]
    month_fa = months_fa[jdate.month - 1]

    # ساخت رشته خروجی
    return f"{weekday_fa}، {jdate.day} {month_fa} {jdate.year} - {jdate.strftime('%H:%M:%S')}"

# ساخت گزارش
def generate_report():
    result_PATH = os.path.join(os.path.dirname(__file__), "result.json")
    with open(result_PATH, 'r') as file:
        report_data = json.load(file)

    message = "گزارش وضعیت سرورها:\n"

    for report in report_data:
        cl_name = report.get("des_server_name", "نامی برای سرور یافت نشد")
        cl_ip = report.get("IP4", "آی‌پی یافت نشد")
        test_name = report.get("IDname", "نام تست یافت نشد")
        test_id = report.get("ID", "شناسه تست یافت نشد")
        error_percentage = report.get("PL", "خطای گزارش نشده")
        last_update = report.get("last_update", "به‌روزرسانی نشده")
        
        if last_update == 0:
            last_update_str = "به‌روزرسانی نشده"
        else:
            last_update_str = get_shamsi_time(last_update)

        if error_percentage == "notreport":
            status = "⚪"
            message += f"\n{status} سرور {cl_name} - {test_name} : گزارشی دریافت نشده\n"
            
        else:
            # تبدیل به عدد و بررسی وضعیت
            try:
                percent = float(error_percentage)
                if percent == 0:
                    status = "🟢"
                elif 1 <= percent <= 49:
                    status = "🟡"
                elif 50 <= percent <= 99:
                    status = "🟠"
                elif percent == 100:
                    status = "🔴" 
                else:
                    status = "⚪" 
            except:
                status = "⚪"
            message += f"\n{status}سرور {cl_name} - {test_name} : درصد اختلال : {error_percentage}% \n"

        message += f"آی‌پی سرور خارج: {cl_ip}\nآخرین به‌روزرسانی: {last_update_str}\n"
    message += f'\n \nسرویس کاهش پینگ <a href="https://t.me/Vip_v2rray">VIP_V2ray</a> \n'
    return message

# ارسال یا ویرایش پیام
# مسیر ذخیره message_id
MESSAGE_ID_FILE = os.path.join(os.path.dirname(__file__), "message_id.txt")
LAST_MESSAGE_FILE = os.path.join(os.path.dirname(__file__), "last_message.txt")
async def send_or_edit_message(bot, message):
    try:
        # بررسی تکراری بودن پیام
        if os.path.exists(LAST_MESSAGE_FILE):
            with open(LAST_MESSAGE_FILE, 'r', encoding='utf-8') as f:
                last_message = f.read()
            if last_message.strip() == message.strip():
                print("پیام تکراری است، نیازی به ارسال یا ویرایش نیست.")
                return

        # بررسی وجود message_id در فایل
        if os.path.exists(MESSAGE_ID_FILE):
            with open(MESSAGE_ID_FILE, 'r') as f:
                message_id = f.read().strip()

            if message_id:
                await bot.edit_message_text(
                    text=message, chat_id=CHANNEL_ID, message_id=int(message_id), parse_mode='HTML'
                )
                print("پیام ویرایش شد.")
            else:
                raise ValueError("message_id موجود نیست.")
        else:
            raise FileNotFoundError("فایل message_id.txt یافت نشد.")
        
    except (FileNotFoundError, ValueError):
        # ارسال پیام جدید
        msg = await bot.send_message(chat_id=CHANNEL_ID, text=message, parse_mode='HTML')
        with open(MESSAGE_ID_FILE, 'w') as f:
            f.write(str(msg.message_id))
        print("پیام جدید ارسال شد:", msg.message_id)
    
    # ذخیره پیام جدید برای بررسی در آینده
    with open(LAST_MESSAGE_FILE, 'w', encoding='utf-8') as f:
        f.write(message.strip())
# تابع اصلی
async def main():
    global last_report
    bot = Bot(token=API_TOKEN)
    me = await bot.get_me()
    print("ربات فعال است:", me.username)
    while True:
        report = generate_report()
        await send_or_edit_message(bot, report)
        print(report)
        await asyncio.sleep(10)

# اجرای برنامه
if __name__ == "__main__":
    while True:
        try:
            asyncio.run(main())
        except Exception as e:
            # ثبت نوع و جزئیات خطا
            print(f"❌ خطا در اجرای ربات: {str(e)}")
            print("جزئیات خطا:")
            print(traceback.format_exc())  # نمایش دقیق نوع و جزئیات خطا
            print("⏳ تلاش مجدد برای راه‌اندازی در 5 ثانیه...")
            time.sleep(5)
