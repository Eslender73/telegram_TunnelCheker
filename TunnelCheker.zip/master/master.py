import socket
import threading
import json
import time
import os
import traceback


# Load config
master_config_PATH = os.path.join(os.path.dirname(__file__), "master_config.json")
with open(master_config_PATH) as f:
    config = json.load(f)

listen_port = config["listen_port"]
timeout_minutes = config["report_timeout_minute"]
clients_info = config["expected_clients"]

# Shared results dictionary
report_data = {}

# Initialize with notreport
def initialize_reports():
    now = time.time()
    for cl_id, cl_data in clients_info.items():
        for test_id, test_name in cl_data["tests"].items():
            key = (int(cl_id), int(test_id))
            report_data[key] = {
                "CL": int(cl_id),
                "IP4": cl_data["CLipv4_M"],
                "des_server_name": cl_data["CLname_M"],
                "ID": int(test_id),
                "IDname": test_name,
                "PL": "notreport",
                "last_update": 0
            }

def handle_client(conn, addr):
    try:
        message = conn.recv(1024).decode().strip()
        print(f"Received: {message} from {addr}")
        parts = dict([p.split("=", 1) for p in message.split(",") if "=" in p]) 
        cl_id = int(parts.get("CL"))
        ip = parts.get("CLipv4")
        des_server = parts.get("CLname")
        test_id = int(parts.get("ID"))
        test_name = parts.get("IDname")
        pl = parts.get("PL")
        last_update = float(parts.get("last_update", time.time()))
        key = (cl_id, test_id)
        report_data[key] = {
            "CL": cl_id,
            "IP4": ip,
            "des_server_name": des_server,
            "ID": test_id,
            "IDname": test_name,
            "PL": pl,
            "last_update": last_update
        }
    except Exception as e:
        print("Error:", e)
    finally:
        conn.close()

def check_timeouts():
    now = time.time()
    for key, data in report_data.items():
        if now - data["last_update"] > timeout_minutes * 60:
            data["PL"] = "notreport"


def save_current_report_to_json():
    # Sort the report data by CL and ID, then create the current report
    current_report = []
    sorted_keys = sorted(report_data.keys())
    for key in sorted_keys:
        data = report_data[key]
        
        current_report.append(data)

    # Save the current report to a JSON file (overwrite the previous report)
    report_file_path = os.path.join(os.path.dirname(__file__), "reactive_report.json")
    with open(report_file_path, 'w') as json_file:
        json.dump(current_report, json_file, indent=4)
    print(f"Current report saved to {report_file_path}")

def print_report():
    sorted_keys = sorted(report_data.keys())
    print("\nCurrent Report:")
    # Initialize the current_report list here
    current_report = []
    for key in sorted_keys:
        data = report_data[key]
        print(f"CL={data['CL']},IP4={data['IP4']},CLname={data['des_server_name']},ID={data['ID']},IDname={data['IDname']},PL={data['PL']}")
    current_report.append(data)
    print("-" * 60)
    save_current_report_to_json()
def server_loop():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", listen_port))
        s.listen()
        print(f"Master server listening on port {listen_port}")
        while True:
            conn, addr = s.accept()
            threading.Thread(target=handle_client, args=(conn, addr)).start()

def monitor_loop():
    while True:
        check_timeouts()
        print_report()
        time.sleep(60)

if __name__ == "__main__":
    while True:
        try:
            initialize_reports()
            threading.Thread(target=server_loop).start()
            monitor_loop()
        except Exception as e:
            # ثبت نوع و جزئیات خطا
            print(f"❌ خطا در اجرای بخش اصلی: {str(e)}")
            print("جزئیات خطا:")
            print(traceback.format_exc())  # نمایش دقیق نوع و جزئیات خطا
            print("⏳ تلاش مجدد برای راه‌اندازی در 5 ثانیه...")
            time.sleep(5)
