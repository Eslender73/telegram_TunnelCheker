#!/bin/bash

# اجرای هرکدوم در بک‌گراند و لاگ‌گیری جدا
/usr/bin/python3 /opt/tunnelmonitor/ping.py >> /var/log/tunnel_ping.log 2>> /var/log/tunnel_ping.err.log &
/usr/bin/python3 /opt/tunnelmonitor/matcher.py >> /var/log/tunnel_matcher.log 2>> /var/log/tunnel_matcher.err.log &
/usr/bin/python3 /opt/tunnelmonitor/master.py >> /var/log/tunnel_master.log 2>> /var/log/tunnel_master.err.log &
/usr/bin/python3 /opt/tunnelmonitor/bot.py >> /var/log/tunnel_bot.log 2>> /var/log/tunnel_bot.err.log &
# صبر دائمی تا سرویس نخوابه
wait
