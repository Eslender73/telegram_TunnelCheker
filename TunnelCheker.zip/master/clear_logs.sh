#!/bin/bash

# حذف فایل‌های لاگ که بیشتر از 1 روز (24 ساعت) از آخرین تغییراتشان گذشته
find /var/log/tunnel_ping.log -mtime +1 -exec rm -f {} \;
find /var/log/tunnel_matcher.log -mtime +1 -exec rm -f {} \;
find /var/log/tunnel_master.log -mtime +1 -exec rm -f {} \;
find /var/log/tunnel_bot.log -mtime +1 -exec rm -f {} \;
# حذف فایل‌های خطای لاگ که بیشتر از 1 روز (24 ساعت) از آخرین تغییراتشان گذشته
find /var/log/tunnel_ping.err.log -mtime +1 -exec rm -f {} \;
find /var/log/tunnel_matcher.err.log -mtime +1 -exec rm -f {} \;
find /var/log/tunnel_master.err.log -mtime +1 -exec rm -f {} \;
find /var/log/tunnel_bot.err.log -mtime +1 -exec rm -f {} \;
