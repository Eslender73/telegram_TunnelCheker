import os
import json
import time

# مسیر نسبی پوشه جاری
base_path = os.path.dirname(os.path.abspath(__file__))
ping_results_path = os.path.join(base_path, "ping_results.json")
current_report_path = os.path.join(base_path, "reactive_report.json")
result_path = os.path.join(base_path, "result.json")

while True:
    try:
        # بررسی اندازه فایل‌ها
        if os.path.getsize(ping_results_path) == 0 or os.path.getsize(current_report_path) == 0:
            print("⏳ یکی از فایل‌ها خالی است. بررسی مجدد پس از ۵ ثانیه...")
            time.sleep(5)
            continue

        # بارگذاری داده‌ها
        with open(ping_results_path, 'r', encoding='utf-8') as f1:
            data1 = json.load(f1)

        with open(current_report_path, 'r', encoding='utf-8') as f2:
            data2 = json.load(f2)

        # ترکیب و مرتب‌سازی بر اساس CL و سپس ID
        merged_data = data1 + data2
        sorted_data = sorted(merged_data, key=lambda x: (x['CL'], x['ID']))

        # بازنویسی فایل result.json
        with open(result_path, 'w', encoding='utf-8') as fout:
            json.dump(sorted_data, fout, ensure_ascii=False, indent=4)

        print("✅ فایل result.json بروزرسانی شد.")
    except Exception as e:
        print(f"❌ خطا در اجرا: {e}")

    # صبر 10 ثانیه
    time.sleep(10)
