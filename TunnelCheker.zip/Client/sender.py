import json
import socket
import time
from datetime import datetime
import os

def load_config():
    config_path = os.path.join(os.path.dirname(__file__), "config.json")
    with open(config_path, "r") as f:
        return json.load(f)

def send_to_master(data, master_ip, master_port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((master_ip, int(master_port)))
            s.sendall(data.encode())
    except Exception as e:
        print("Error sending to master:", e)
def format_data(result):
    # داده‌ها به فرمت مورد نظر شما تبدیل می‌شود
    return f"CL={result['CL']},CLipv4={result['CLipv4']},CLname={result['CLname']},ID={result['ID']},IDname={result['IDname']},PL={result['PL']},last_update={result['last_update']}"

def main():
    config = load_config()
    master_ip, master_port = config["Master_server_info"].split(":")
    results_path = os.path.join(os.path.dirname(__file__), "ping_results.json")

    while True:
        # Load the results from the JSON file
        try:
            with open(results_path, "r") as f:
                results = json.load(f)

            # Send each result line by line
            for result in results:
                msg = format_data(result)
                send_to_master(msg, master_ip, master_port)
                print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - Data sent to master: {msg}")

        except Exception as e:
            print(f"Error loading or sending results: {e}")

        # Wait for 1 minute before sending again
        time.sleep(60)

if __name__ == "__main__":
    main()
