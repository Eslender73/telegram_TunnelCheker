import json
import time
import os
import ipaddress
import subprocess
from datetime import datetime

def load_config():
    config_path = os.path.join(os.path.dirname(__file__), "config.json")
    with open(config_path, "r") as f:
        return json.load(f)

def calculate_packet_loss(ip, count):
    """
    Calculates packet loss. Timeout management is handled by the ping command itself using the '-w' flag.
    """
    try:
        ip_obj = ipaddress.ip_address(ip)
        ip_flag = "-4" if ip_obj.version == 4 else "-6"
        command = [
            "env", "LANG=C", "ping", 
            ip_flag, 
            "-c", str(count),
            ip
        ]
        
        print(f"DEBUG: Running command: {' '.join(command)}")

        result = subprocess.run(
            command,
            capture_output=True,
            text=True

        )
        if result.returncode > 1:
            print(f"ERROR: Ping command failed for {ip} with return code {result.returncode}.")
            print(f"DEBUG: STDERR for {ip}:\n{result.stderr}")
            return 100.0

        output = result.stdout
        packet_loss_line = [line for line in output.split("\n") if "packet loss" in line]
        
        if packet_loss_line:
            packet_loss_str = packet_loss_line[0].split("%")[0].split()[-1]
            return float(packet_loss_str)
        else:
            # اگر پینگ به دلیل deadline تمام شود ولی خروجی آماری تولید نکند
            print(f"ERROR: Could not parse packet loss for {ip}. The command may have been terminated by deadline before producing statistics.")
            return 100.0

    except Exception as e:
        # دیگر خطای TimeoutExpired از اینجا رخ نمی‌دهد، اما این Exception کلی برای موارد پیش‌بینی نشده خوب است
        print(f"ERROR: An unexpected error occurred while processing IP {ip}: {e}")
        return 100.0

def main():
    config = load_config()
    test_delay = config["Test_delay"]
    test_count = config["Test_count"]
    
    while True:
        current_report = []
        
        for entry in config["ID_ip4/ip6_name"]:
            try:
                id_, ip, name = entry.split(",")
                # حذف فاصله‌های اضافی از IP
                ip = ip.strip()
                pl = calculate_packet_loss(ip, test_count)
                result = {
                    "CL": config['CL'],
                    "CLipv4": config['CLipv4'],
                    "CLname": config['CLname'],
                    "ID": id_,
                    "IDname": name,
                    "PL": pl,
                    "last_update": time.time()
                }
                current_report.append(result)

                print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - Test taken for ID={id_}, IP={ip}, PL={pl}%")
            except Exception as e:
                print("Error in test loop:", e)

        report_path = os.path.join(os.path.dirname(__file__), "ping_results.json")
        with open(report_path, "w") as f:
            json.dump(current_report, f, indent=4)

        print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - Current test results saved to ping_results.json")

        print(f"Waiting for {test_delay} minutes before running tests again...")
        time.sleep(test_delay * 60)

if __name__ == "__main__":
    main()